#!/sbin/sh

if [ -f /boot/ramdisk-boot.img ] && [ ! -f /boot/ramdisk-recovery.img ]; then
  mv /boot/ramdisk.img /boot/ramdisk-recovery.img
  mv /boot/ramdisk-boot.img /boot/ramdisk.img
  if [ ! -z $(cat /system/build.prop | grep ^ro.product.device=rpi3) ] && [ ! -z $(cat /system/build.prop | grep ^ro.hardware.gralloc=minigbm) ]; then
    sed -i 's/#dtoverlay=vc4-kms-v3d,cma-256/dtoverlay=vc4-kms-v3d,cma-256/' /boot/config.txt
    sed -i 's/#mask_gpu_interrupt0=0x400/mask_gpu_interrupt0=0x400/' /boot/config.txt
  fi
else
  exit 1
fi

exit 0
